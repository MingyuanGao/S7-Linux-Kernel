#ifndef _ISL_INCLUDE_ISL_STDINT_H
#define _ISL_INCLUDE_ISL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "isl 0.16.1"
/* generated using gnu compiler x86_64-linux-gnu-gcc (Ubuntu 4.9.2-10ubuntu13) 4.9.2 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
